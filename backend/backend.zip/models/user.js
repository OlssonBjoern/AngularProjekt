const mongoose = require('mongoose');
const uniqueValidator = require('mongoose-unique-validator');
// User model
const userSchema = mongoose.Schema({
  email: {type: String, required: true, unique: true},
  password: {type: String, required: true}
});

// Unique validator for email
userSchema.plugin(uniqueValidator);

module.exports = mongoose.model('User', userSchema);
